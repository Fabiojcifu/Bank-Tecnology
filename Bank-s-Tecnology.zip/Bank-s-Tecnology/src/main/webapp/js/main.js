var id_usuario = new URL(location.href).searchParams.get("id_usuario");
var user;

$(document).ready(function () {
    $(function () {
        $('[data-toggle="tooltip"]').tooltip();
    });

    getUsuario().then(function () {
        
        $("#mi-perfil-btn").attr("href","profile.html?id_usuario=" + id_usuario);
        
        //$("#user-saldo").html(user.saldo.toFixed(2) + "$");

        getProducto(false, "ASC");

        //$("#ordenar-genero").click(ordenarProducto);
    });
});


async function getUsuario() {

    await $.ajax({
        type: "GET",
        dataType: "html",
        url: "./ServletUsuarioPedir",
        data: $.param({
            id_usuario: id_usuario
        }),
        success: function (result) {
            let parsedResult = JSON.parse(result);

            if (parsedResult != false) {
                user = parsedResult;
            } else {
                console.log("Error recuperando los datos del usuario");
            }
        }
    });
}

function getProducto(ordenar, orden) {    //getDestino
    $.ajax({
        type: "GET",
        dataType: "html",
        url: "./ServletProductoListar",     //ServletPeliculaListar
        data: $.param({
            ordenar: ordenar,
            orden: orden
        }),
        success: function (result) {
            let parsedResult = JSON.parse(result);

            if (parsedResult != false) {
                mostrarProducto(parsedResult);    //mostrarProducto
            } else {
                console.log("Error recuperando los datos de los Destino");
            }
        }
    });
}

function mostrarProducto(producto) {
    let contenido = "";

    $.each(producto, function (index, producto) {

        producto = JSON.parse(producto);
        contenido += '<tr><th scope="row">' + producto.id_producto + '</th>' +
                '<td>' + producto.nom_producto + '</td>' +
                '<td>' + producto.des_producto + '</td>' +
                '<td>' + producto.precio + '</td>' +
                '<td>' + producto.cantidad + '</td>' +
                '<td>' + producto.id_categoria + '</td>';
    });
    $("#producto-tbody").html(contenido);  //destino-tbody
}