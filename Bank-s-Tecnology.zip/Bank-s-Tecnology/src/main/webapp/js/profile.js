var id_usuario = new URL(location.href).searchParams.get("id_usuario");
var user;

$(document).ready(function () {

    fillUsuario().then(function () {

        //$("#user-saldo").html("$" + user.saldo.toFixed());

        getAlquiladas(user.id_usuario);
    });

    $("#reservar-btn").attr("href", `home.html?id_usuario=${id_usuario}`);

    $("#form-modificar").on("submit", function (event) {
        event.preventDefault();
        modificarUsuario();
    });

    $("#aceptar-eliminar-cuenta-btn").click(function () {

        eliminarCuenta().then(function () {
            location.href = "index.html";
        })
    })

});

async function fillUsuario() {
    await $.ajax({
        type: "GET",
        dataType: "html",
        url: "./ServletUsuarioPedir",
        data: $.param({
            id_usuario: id_usuario,
        }),
        success: function (result) {
            let parsedResult = JSON.parse(result);

            if (parsedResult != false) {
                user = parsedResult;

                $("#input-id_usuario").val(parsedResult.id_usuario);
                //$("#input-contrasena").val(parsedResult.contrasena);
                $("#input-nombres_usu").val(parsedResult.nombres_usu);
                $("#input-apellidos_usu").val(parsedResult.apellidos_usu);
                $("#input-direccion").val(parsedResult.direccion);
                //$("#input-saldo").val(parsedResult.saldo.toFixed(2));
                //$("#input-premium").prop("checked", parsedResult.premium);
                $("#input-ciudad").val(parsedResult.ciudad);
                $("#input-telefono").val(parsedResult.telefono);
                $("#input-contrasena").val(parsedResult.contrasena);

            } else {
                console.log("Error recuperando los datos del usuario");
            }
        }
    });
}

function getAlquiladas(id_usuario) {


    $.ajax({
        type: "GET",
        dataType: "html",
        url: "./ServletAlquilerListar",
        data: $.param({
            id_usuario: id_usuario,
        }),
        success: function (result) {
            let parsedResult = JSON.parse(result);

            if (parsedResult != false) {

                mostrarHistorial(parsedResult)

            } else {
                console.log("Error recuperando los datos de las reservas");
            }
        }
    });
}

function modificarUsuario() {
    let id_usuario = $("#input-id_usuario").val();
    let nombres_usu = $("#input-nombres_usu").val();
    let apellidos_usu = $("#input-apellidos_usu").val();
    let direccion = $("#input-direccion").val();
    let ciudad = $("#input-ciudad").val();
    let telefono = $("#input-telefono").val();
    let contrasena = $("#input-contrasena").val();
    
    $.ajax({
        type: "GET",
        dataType: "html",
        url: "./ServletUsuarioModificar",
        data: $.param({
            id_usuario: id_usuario,
            //contrasena: contrasena,
            nombres_usu: nombres_usu,
            apellidos_usu: apellidos_usu,
            direccion: direccion,
            ciudad: ciudad,
            telefono: telefono,
            contrasena: contrasena
        }),
        success: function (result) {
            if (result != false) {
                $("#modificar-error").addClass("d-none");
                $("#modificar-exito").removeClass("d-none");
            } else {
                $("#modificar-error").removeClass("d-none");
                $("#modificar-exito").addClass("d-none");
            }

            setTimeout(function () {
                location.reload();
            }, 3000);

        }
    });

}

async function eliminarCuenta() {

    await $.ajax({
        type: "GET",
        dataType: "html",
        url: "./ServletUsuarioEliminar",
        data: $.param({
            id_usuario: id_usuario
        }),
        success: function (result) {

            if (result != false) {

                console.log("Usuario eliminado")

            } else {
                console.log("Error eliminando el usuario");
            }
        }
    });
}