package controller;

import java.sql.ResultSet;
import java.sql.Statement;
import com.google.gson.Gson;
import beans.Usuario;
import connection.DBConnection;
import java.util.HashMap;
import java.util.Map;

public class UsuarioController implements IUsuarioController {

    @Override
    public String login(int id_usuario, String contrasena) {
        Gson gson = new Gson();
        DBConnection con = new DBConnection();
        String sql = "Select * from usuario where id_usuario = '" + id_usuario
                + "' and contrasena = '" + contrasena + "'";

        try {
            Statement st = con.getConnection().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                //int id_usuario = rs.getInt("id_usuario");
                String nombres_usu = rs.getString("nombres_usu");
                String apellidos_usu = rs.getString("apellidos_usu");
                String direccion = rs.getString("direccion");
                String ciudad = rs.getString("ciudad"); 
                int telefono = rs.getInt("telefono");
                //String contrasena = rs.getString("contrasena");
                Usuario usuarios = new Usuario(id_usuario, nombres_usu, apellidos_usu, direccion,ciudad,telefono,contrasena);
                return gson.toJson(usuarios);
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        } finally {
            con.desconectar();
        }
        return "false";
    }
    
    @Override
    public String register(int id_usuario, String nombres_usu, String apellidos_usu, String direccion,
            String ciudad, int telefono,String contrasena ) {

        Gson gson = new Gson();

        DBConnection con = new DBConnection();
        String sql = "Insert into usuario values('" + id_usuario + "', '" + nombres_usu + "', '" + apellidos_usu
                + "', '" + direccion + "', '" + ciudad + "', '" + telefono + "', '" + contrasena + "')";

        try {
            Statement st = con.getConnection().createStatement();
            st.executeUpdate(sql);
              //me falla en esto estoy declarando mal las variables no se
            Usuario usuario = new Usuario(id_usuario, nombres_usu, apellidos_usu,direccion, ciudad, telefono,contrasena);
            //public Usuario(int id_usuario, String nombres_usu, String apellidos_usu, String direccion, String ciudad, int telefono, String contrasena) {
            st.close();

            return gson.toJson(usuario);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());

        } finally {
            con.desconectar();
        }

        return "false";

    }

  
     @Override
    public String pedir(int id_usuario) {

        Gson gson = new Gson();

        DBConnection con = new DBConnection();
        String sql = "Select * from usuario where id_usuario = '" + id_usuario + "'";

        try {

            Statement st = con.getConnection().createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                String nombres_usu = rs.getString("nombres_usu");
                //String nombre = rs.getString("nombre");
                String apellidos_usu = rs.getString("apellidos_usu");
                String direccion = rs.getString("direccion");
                String ciudad = rs.getString("ciudad");
                int telefono = rs.getInt("telefono");
                //double saldo = rs.getDouble("saldo");
                //boolean premium = rs.getBoolean("premium");
                String contrasena = rs.getString("contrasena");

                Usuario usuario = new Usuario(id_usuario, 
                        nombres_usu, apellidos_usu, direccion, ciudad,telefono,contrasena);

                return gson.toJson(usuario);
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        } finally {
            con.desconectar();
        }

        return "false";
    }
    
    @Override
     public String modificar(int id_usuario, 
            String nuevonombres_usu, String nuevosapellidos_usu,
            String nuevodireccion, String nuevociudad, int nuevotelefono, String nuevocontrasena) {

        DBConnection con = new DBConnection();

        String sql = "Update usuario set nombres_usu = '" + nuevonombres_usu
                + "', apellidos_usu = '" + nuevosapellidos_usu + "', direccion = '"
                + nuevodireccion + "', ciudad = '" + nuevociudad + "', contrasena = '"
                + nuevocontrasena+"'";

        //if (nuevoPremium == true) {
            //sql += " 1 ";
        //} else {
            //sql += " 0 ";
        //}

        sql += " where id_usuario = " + id_usuario;

        try {

            Statement st = con.getConnection().createStatement();
            st.executeUpdate(sql);

            return "true";
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        } finally {
            con.desconectar();
        }

        return "false";

    }
     
   
    @Override
    public String eliminar(int id_usuario) {

        DBConnection con = new DBConnection();

        //String sql1 = "Delete from alquiler where username = '" + username + "'";
        String sql2 = "Delete from usuario where id_usuario = '" + id_usuario + "'";

        try {
            Statement st = con.getConnection().createStatement();
            //st.executeUpdate(sql1);
            st.executeUpdate(sql2);

            return "true";
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        } finally {
            con.desconectar();
        }

        return "false";
    }
}