package controller;

import java.util.Map;

public interface IUsuarioController {

    public String login(int id_usuario, String contrasena);
    
    
    public String register(int id_usuario, 
            String nombre_usu, String apellidos_usu, String direccion, String ciudad, int telefono,String contrasena);
    
    public String pedir(int id_usuario);
    
    public String modificar(int id_usuario,
            String nuevoNombres_usu, String nuevosApellidos_usu, String nuevodireccion,
            String nuevociudad, int nuevotelefono,String nuevaContrasena);
    
   
    
    public String eliminar(int id_usuario);
}
