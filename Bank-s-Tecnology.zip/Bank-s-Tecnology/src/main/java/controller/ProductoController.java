
package controller;

import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.google.gson.Gson;
import beans.Producto;
import connection.DBConnection;
//lo que entiendo aqui es que los datos no considen con iproductocontroller
public class ProductoController implements IProductoController {

    
     @Override
    public String listar(boolean ordenar, String orden) {

        Gson gson = new Gson();

        DBConnection con = new DBConnection();
        String sql = "Select * from producto";

        if (ordenar == true) {
            sql += " order by categoria " + orden;
        }

        List<String> producto = new ArrayList<String>();

        try {

            Statement st = con.getConnection().createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {

                int id_producto = rs.getInt("id_producto");
                String nom_producto = rs.getString("nom_producto");
                String des_producto = rs.getString("des_producto");
                int precio = rs.getInt("precio");
                int cantidad = rs.getInt("cantidad");
                int id_categoria = rs.getInt("id_categoria");

                Producto productos = new Producto(id_producto,nom_producto, des_producto , precio , cantidad, id_categoria);

                producto.add(gson.toJson(productos));

            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        } finally {
            con.desconectar();
        }

        return gson.toJson(producto);
    }
   @Override
    public String comprar(int id_compra, String observaciones) {

        Timestamp fecha = new Timestamp(new Date().getTime());
        DBConnection con = new DBConnection();
        String sql = "Insert into compra values ('" + id_compra + "',  '" + fecha + "', '" + observaciones + ")";

        try {
            Statement st = con.getConnection().createStatement();
            st.executeUpdate(sql);

            String modificar = modificar(id_compra);

            if (modificar.equals("true")) {
                return "true";
            }

        } catch (Exception ex) {
            System.out.println(ex.toString());
        } finally {
            con.desconectar();
        }
        return "false";
        
        
    }
    
    
    @Override
    public String devolver(int id_producto, String nom_producto) {

        DBConnection con = new DBConnection();
        String sql = "Delete from producto where id_producto= " + id_producto + " and nom_producto = '" 
                + nom_producto + "' limit 1";

        try {
            Statement st = con.getConnection().createStatement();
            st.executeQuery(sql);

            //this.sumarCantidad();

            return "true";
        } catch (Exception ex) {
            System.out.println(ex.toString());
        } finally {
            con.desconectar();
        }

        return "false";
    }
  @Override
    public String modificar(int id) {

        DBConnection con = new DBConnection();
        String sql = "Update producto set cantidad = (cantidad - 1) where id_producto = " + id;

        try {
            Statement st = con.getConnection().createStatement();
            st.executeUpdate(sql);

            return "true";
        } catch (Exception ex) {
            System.out.println(ex.toString());
        } finally {
            con.desconectar();
        }

        return "false";

    }    

    public String Comprar(int id_producto, String observaciones) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
