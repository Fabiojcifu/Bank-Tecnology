
package controller;





public interface IProductoController {
     
    //public String producto(int id_producto,String nom_producto,String des_producto,int precio,int cantidad,int id_categoria);
    //puede ser que por esta funcion me vote error en la funcion
    //producto controller
    //aqui la profe lo tiene como boolean
    
    public String listar(boolean ordenar, String orden);
    
    public String comprar(int id_compra, String observaciones);
    
    public String devolver(int id, String nom_producto);
     
    public String modificar(int id_compra);


    
}
