
package controller;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import java.util.List;

import com.google.gson.Gson;

import beans.Compra;
import connection.DBConnection;

//esta tabla esta copiada con la tabla alquiler controller se cambio la sentencia sql
//comparando la tabla de la base de datos de la profesora emily
public class CompraController {
    
    public String listarCompras(double id_usuario) {

        Gson gson = new Gson();

        DBConnection con = new DBConnection();

        String sql = "Select l.id_producto, l.nom_producto, l.des_producto, l.precio, 1.cantidad, a.fecha from compra l "
                + "inner join compra a on l.id = a.id_usuario inner join usuario u on a.nombres_usuario = u.nombres_usuarios "
                + "where a.id_usuario = '" + id_usuario + "'";

        List<String> compras = new ArrayList<String>();

        try {

            Statement st = con.getConnection().createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                int id_compra = rs.getInt("id_compra");
                //int id_usuario= rs.getInt("id_usuario");
                Date FechaCompra = rs.getDate("FechaCompra");
                String ciudad = rs.getString("ciudad");
                String observaciones = rs.getString("observaciones");
                //String ciudad = rs.getString("ciudad");
                //no se por que en esta parte me esta arrogando este error y es en todas
                Compra compra = new Compra(id_compra, FechaCompra,ciudad, observaciones );

                compras.add(gson.toJson(compra));
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        } finally {
            con.desconectar();
        }
        return gson.toJson(compras);
    }
    
}
