package test;

import beans.Categoria;
import connection.DBConnection;
import java.sql.ResultSet;
import java.sql.Statement;
import beans.Producto;

public class OperacionesBD {
    
    public static void main(String[] args) {
        actualizarProducto(101,10);
        listarProducto();
    }
    
    public static void actualizarProducto(int id_producto, int cantidad ) {
        
        DBConnection con = new DBConnection();
        String sql = "UPDATE producto SET cantidad = " + "'" + cantidad + "'WHERE id_producto = " + id_producto;
                try {
            Statement st = con.getConnection().createStatement();
            st.executeUpdate(sql);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        } finally {
            con.desconectar();
        }
    }
    
    public static void listarProducto() {
         DBConnection con = new DBConnection();
        String sql = "SELECT * FROM producto";
        
         try {
          Statement st = con.getConnection().createStatement();
          ResultSet rs = st.executeQuery(sql);
          
          while(rs.next()){
              int id_producto = rs.getInt("id_producto");
              String nom_producto = rs.getString("nom_producto");  
              String des_producto = rs.getString("des_producto");
              int precio = rs.getInt("precio");
              int cantidad = rs.getInt("cantidad");
              int id_categoria = rs.getInt("id_categoria");
              Producto producto = new Producto (id_producto, nom_producto, des_producto, precio, cantidad, id_categoria);
              System.out.println(producto.toString());
          }
         st.executeQuery(sql);  
        }catch(Exception ex){ 
            System.out.println(ex.getMessage());   
        }
        
        finally {
            con.desconectar();
        }
    }

}
