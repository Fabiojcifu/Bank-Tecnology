package beans;

import java.sql.Date;

public class Compra {
    private int id_producto;
    //private int id_usuario;
    private Date fecha;
    private String ciudad;
    private String observaciones;

    public Compra(int id_producto, Date fecha, String ciudad, String observaciones) {
        this.id_producto = id_producto;
        this.fecha = fecha;
        this.ciudad = ciudad;
        this.observaciones = observaciones;
    }

    public int getId_producto() {
        return id_producto;
    }

    public void setId_producto(int id_producto) {
        this.id_producto = id_producto;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    @Override
    public String toString() {
        return "Compra{" + "id_producto=" + id_producto + ", fecha=" + fecha + ", ciudad=" + ciudad + ", observaciones=" + observaciones + '}';
    }

   
}